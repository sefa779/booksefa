﻿using System;
namespace WebApi.Common
{
	public enum GenreEnum
	{
		PersonalGrowth=1,

	    ScienceFiction,

		Noval,
	    
	}
}

